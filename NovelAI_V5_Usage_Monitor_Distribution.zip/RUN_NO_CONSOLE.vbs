﻿Option Explicit

Dim shell, fso, folder, scriptPath, pythonw, cmd, candidates, p, found
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

folder = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fso.BuildPath(folder, "novelai_monitor.py")

If Not fso.FileExists(scriptPath) Then
    MsgBox "novelai_monitor.py 파일을 이 런처와 같은 폴더에 넣어주세요." & vbCrLf & _
           "현재 폴더: " & folder, 48, "NovelAI V5 Usage Monitor"
    WScript.Quit
End If

found = False
candidates = Array( _
    "pythonw.exe", _
    "C:\Windows\pyw.exe" _
)

For Each p In candidates
    On Error Resume Next
    If InStr(p, "\") > 0 Then
        If fso.FileExists(p) Then
            pythonw = p
            found = True
            Exit For
        End If
    Else
        Err.Clear
        shell.Run "cmd /c where " & p & " >nul 2>&1", 0, True
        If Err.Number = 0 Then
            pythonw = p
            found = True
            Exit For
        End If
    End If
    On Error GoTo 0
Next

If Not found Then
    ' pyw launcher가 있는 환경을 우선 시도
    On Error Resume Next
    shell.Run "pyw """ & scriptPath & """", 0, False
    If Err.Number = 0 Then
        WScript.Quit
    End If
    On Error GoTo 0

    MsgBox "pythonw.exe 또는 pyw를 찾지 못했습니다." & vbCrLf & _
           "Python 설치 시 'Add Python to PATH' 옵션을 확인해주세요.", _
           16, "NovelAI V5 Usage Monitor"
    WScript.Quit
End If

cmd = """" & pythonw & """ """ & scriptPath & """"
shell.Run cmd, 0, False
