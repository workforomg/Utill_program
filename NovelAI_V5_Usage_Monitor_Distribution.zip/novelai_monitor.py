import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox

import threading
import time
import requests
import pystray
import keyring

from PIL import Image, ImageDraw
from datetime import datetime


# ============================================================
# NovelAI API
# ============================================================

BASE_URL = "https://image.novelai.net"

USER_DATA_URL = f"{BASE_URL}/user/data"
SUBSCRIPTION_URL = f"{BASE_URL}/user/subscription"


# ============================================================
# Application
# ============================================================

APP_NAME = "NovelAI V5 Usage Monitor"

KEYRING_SERVICE = "NovelAI-V5-Usage-Monitor"
KEYRING_USERNAME = "persistent-api-token"

DEFAULT_THRESHOLD = "100"
DEFAULT_INTERVAL = "60"

# 0 -> 100% 약 7일 기준
REFILL_SECONDS_PER_PERCENT = (
    7 * 24 * 60 * 60
) / 100


# ============================================================
# Notifications
# ============================================================

try:
    from plyer import notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False


# ============================================================
# Theme
# ============================================================

ctk.set_appearance_mode("dark")

COLORS = {
    "background": "#0b0b14",

    "card": "#151524",
    "card_secondary": "#10101c",

    "border": "#29283d",

    "purple": "#8d72ff",
    "purple_hover": "#9e89ff",
    "purple_dark": "#6650c9",
    "purple_soft": "#b6a8ff",

    "text": "#f1efff",

    "muted": "#9692ad",
    "muted_dark": "#6c697e",

    "green": "#68d5a3",
    "yellow": "#e4bb68",
    "red": "#e77885",
    "blue": "#78a8ff",
}


# ============================================================
# Main Application
# ============================================================

class NovelAIUsageMonitor:

    def __init__(self):

        self.root = ctk.CTk()

        self.root.title(APP_NAME)
        self.root.geometry("640x945")
        self.root.minsize(410, 945)

        self.root.configure(
            fg_color=COLORS["background"]
        )

        # ----------------------------------------------------
        # Runtime state
        # ----------------------------------------------------

        self.running = False
        self.alarm_triggered = False

        self.current_percent = None
        self.last_usage = None

        self.is_connected = False
        self.subscription_tier = None

        self.tray_icon = None
        self.tray_thread = None

        self.app_exiting = False

        # ----------------------------------------------------
        # UI
        # ----------------------------------------------------

        self.create_ui()

        # X 버튼 → 시스템 트레이
        self.root.protocol(
            "WM_DELETE_WINDOW",
            self.hide_to_tray
        )

        # 트레이
        self.create_tray()

        # 저장 토큰 자동 로드
        self.load_saved_token()


    # ========================================================
    # UI
    # ========================================================

    def create_ui(self):

        self.root.grid_columnconfigure(
            0,
            weight=1
        )

        # ====================================================
        # Header
        # ====================================================

        header = ctk.CTkFrame(
            self.root,
            fg_color="transparent"
        )

        header.grid(
            row=0,
            column=0,
            sticky="ew",
            padx=30,
            pady=(26, 8)
        )

        header.grid_columnconfigure(
            0,
            weight=1
        )

        title_area = ctk.CTkFrame(
            header,
            fg_color="transparent"
        )

        title_area.grid(
            row=0,
            column=0,
            sticky="w"
        )

        ctk.CTkLabel(
            title_area,
            text="NOVELAI",
            text_color=COLORS["purple"],
            font=ctk.CTkFont(
                size=12,
                weight="bold"
            )
        ).pack(
            anchor="w"
        )

        ctk.CTkLabel(
            title_area,
            text="V5 Usage Monitor",
            text_color=COLORS["text"],
            font=ctk.CTkFont(
                size=28,
                weight="bold"
            )
        ).pack(
            anchor="w"
        )

        ctk.CTkLabel(
            title_area,
            text="Opus V5 Usage Limit Monitor",
            text_color=COLORS["muted"],
            font=ctk.CTkFont(
                size=12
            )
        ).pack(
            anchor="w",
            pady=(2, 0)
        )

        self.tray_button = ctk.CTkButton(
            header,
            text="─  트레이로",
            width=115,
            height=36,
            fg_color=COLORS["card"],
            hover_color=COLORS["card_secondary"],
            border_width=1,
            border_color=COLORS["border"],
            command=self.hide_to_tray
        )

        self.tray_button.grid(
            row=0,
            column=1,
            sticky="ne"
        )


        # ====================================================
        # Account Card
        # ====================================================

        account_card = self.create_card(
            row=1
        )

        account_card.grid_columnconfigure(
            0,
            weight=1
        )

        ctk.CTkLabel(
            account_card,
            text="계정 연결",
            text_color=COLORS["text"],
            font=ctk.CTkFont(
                size=15,
                weight="bold"
            )
        ).grid(
            row=0,
            column=0,
            columnspan=2,
            sticky="w",
            padx=20,
            pady=(18, 6)
        )

        # 연결 상태
        self.account_status_label = ctk.CTkLabel(
            account_card,
            text="Persistent API Token을 입력해주세요.",
            text_color=COLORS["muted"],
            font=ctk.CTkFont(
                size=12
            ),
            anchor="w"
        )

        self.account_status_label.grid(
            row=1,
            column=0,
            columnspan=2,
            sticky="ew",
            padx=20
        )

        # 구독 상태
        self.subscription_status_label = ctk.CTkLabel(
            account_card,
            text="",
            text_color=COLORS["muted"],
            font=ctk.CTkFont(
                size=13,
                weight="bold"
            ),
            anchor="w"
        )

        self.subscription_status_label.grid(
            row=2,
            column=0,
            columnspan=2,
            sticky="ew",
            padx=20,
            pady=(3, 12)
        )

        # ----------------------------------------------------
        # Token
        # ----------------------------------------------------

        self.token_var = tk.StringVar()

        self.token_entry = ctk.CTkEntry(
            account_card,
            textvariable=self.token_var,
            show="●",
            placeholder_text="Persistent API Token",
            height=43,
            fg_color=COLORS["card_secondary"],
            border_color=COLORS["border"],
            text_color=COLORS["text"]
        )

        self.token_entry.grid(
            row=3,
            column=0,
            sticky="ew",
            padx=(20, 8),
            pady=(0, 18)
        )

        self.connect_button = ctk.CTkButton(
            account_card,
            text="연결",
            width=95,
            height=43,
            fg_color=COLORS["purple"],
            hover_color=COLORS["purple_hover"],
            command=self.connect_account
        )

        self.connect_button.grid(
            row=3,
            column=1,
            padx=(0, 20),
            pady=(0, 18)
        )

        self.disconnect_button = ctk.CTkButton(
            account_card,
            text="연결 해제",
            width=95,
            height=43,
            fg_color="#463041",
            hover_color="#593b50",
            command=self.disconnect_account
        )


        # ====================================================
        # Usage Card
        # ====================================================

        usage_card = self.create_card(
            row=2
        )

        ctk.CTkLabel(
            usage_card,
            text="V5 USAGE LIMIT",
            text_color=COLORS["muted"],
            font=ctk.CTkFont(
                size=11,
                weight="bold"
            )
        ).pack(
            pady=(22, 0)
        )

        self.percent_label = ctk.CTkLabel(
            usage_card,
            text="--%",
            text_color=COLORS["text"],
            font=ctk.CTkFont(
                size=62,
                weight="bold"
            )
        )

        self.percent_label.pack()

        self.usage_state_label = ctk.CTkLabel(
            usage_card,
            text="NovelAI 계정을 연결해주세요.",
            text_color=COLORS["muted"],
            font=ctk.CTkFont(
                size=14
            )
        )

        self.usage_state_label.pack(
            pady=(0, 4)
        )

        self.next_percent_label = ctk.CTkLabel(
            usage_card,
            text="",
            text_color=COLORS["muted_dark"],
            font=ctk.CTkFont(
                size=12
            )
        )

        self.next_percent_label.pack()

        self.target_eta_label = ctk.CTkLabel(
            usage_card,
            text="",
            text_color=COLORS["purple_soft"],
            font=ctk.CTkFont(
                size=13,
                weight="bold"
            )
        )

        self.target_eta_label.pack(
            pady=(3, 22)
        )


        # ====================================================
        # Alarm Settings
        # ====================================================

        settings_card = self.create_card(
            row=3
        )

        settings_card.grid_columnconfigure(
            (0, 1, 2),
            weight=1
        )

        ctk.CTkLabel(
            settings_card,
            text="알람 설정",
            text_color=COLORS["text"],
            font=ctk.CTkFont(
                size=15,
                weight="bold"
            )
        ).grid(
            row=0,
            column=0,
            columnspan=3,
            sticky="w",
            padx=20,
            pady=(18, 14)
        )

        self.create_field_label(
            settings_card,
            "조건",
            0
        )

        self.create_field_label(
            settings_card,
            "목표 퍼센트",
            1
        )

        self.create_field_label(
            settings_card,
            "확인 주기(초)",
            2
        )

        self.condition_var = tk.StringVar(
            value="이상"
        )

        self.condition_menu = ctk.CTkOptionMenu(
            settings_card,
            variable=self.condition_var,
            values=[
                "이상",
                "정확히",
                "이하"
            ],
            height=42,
            fg_color=COLORS["card_secondary"],
            button_color=COLORS["purple_dark"],
            button_hover_color=COLORS["purple"],
            dropdown_fg_color=COLORS["card"],
            dropdown_hover_color=COLORS["purple_dark"],
            command=self.on_target_setting_changed
        )

        self.condition_menu.grid(
            row=2,
            column=0,
            sticky="ew",
            padx=(20, 7),
            pady=(5, 20)
        )

        self.threshold_var = tk.StringVar(
            value=DEFAULT_THRESHOLD
        )

        self.threshold_entry = ctk.CTkEntry(
            settings_card,
            textvariable=self.threshold_var,
            justify="center",
            height=42,
            fg_color=COLORS["card_secondary"],
            border_color=COLORS["border"]
        )

        self.threshold_entry.grid(
            row=2,
            column=1,
            sticky="ew",
            padx=7,
            pady=(5, 20)
        )

        self.interval_var = tk.StringVar(
            value=DEFAULT_INTERVAL
        )

        self.interval_entry = ctk.CTkEntry(
            settings_card,
            textvariable=self.interval_var,
            justify="center",
            height=42,
            fg_color=COLORS["card_secondary"],
            border_color=COLORS["border"]
        )

        self.interval_entry.grid(
            row=2,
            column=2,
            sticky="ew",
            padx=(7, 20),
            pady=(5, 20)
        )

        self.threshold_var.trace_add(
            "write",
            self.on_threshold_changed
        )


        # ====================================================
        # Main Buttons
        # ====================================================

        button_frame = ctk.CTkFrame(
            self.root,
            fg_color="transparent"
        )

        button_frame.grid(
            row=4,
            column=0,
            sticky="ew",
            padx=30,
            pady=10
        )

        button_frame.grid_columnconfigure(
            (0, 1),
            weight=1
        )

        self.refresh_button = ctk.CTkButton(
            button_frame,
            text="새로고침",
            height=46,
            fg_color=COLORS["card"],
            hover_color=COLORS["card_secondary"],
            border_width=1,
            border_color=COLORS["border"],
            command=self.refresh_once
        )

        self.refresh_button.grid(
            row=0,
            column=0,
            sticky="ew",
            padx=(0, 6)
        )

        self.start_button = ctk.CTkButton(
            button_frame,
            text="모니터링 시작",
            height=46,
            fg_color=COLORS["purple"],
            hover_color=COLORS["purple_hover"],
            command=self.toggle_monitoring
        )

        self.start_button.grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(6, 0)
        )


        # ====================================================
        # Status Card
        # ====================================================

        status_card = self.create_card(
            row=5
        )

        self.status_label = ctk.CTkLabel(
            status_card,
            text="● 대기 중",
            text_color=COLORS["muted"],
            anchor="w"
        )

        self.status_label.pack(
            fill="x",
            padx=18,
            pady=(14, 3)
        )

        self.last_check_label = ctk.CTkLabel(
            status_card,
            text="마지막 확인: -",
            text_color=COLORS["muted_dark"],
            anchor="w",
            font=ctk.CTkFont(
                size=11
            )
        )

        self.last_check_label.pack(
            fill="x",
            padx=18,
            pady=(0, 14)
        )


    # ========================================================
    # UI Helpers
    # ========================================================

    def create_card(self, row):

        card = ctk.CTkFrame(
            self.root,
            fg_color=COLORS["card"],
            corner_radius=16,
            border_width=1,
            border_color=COLORS["border"]
        )

        card.grid(
            row=row,
            column=0,
            sticky="ew",
            padx=30,
            pady=8
        )

        return card


    def create_field_label(
        self,
        parent,
        text,
        column
    ):

        ctk.CTkLabel(
            parent,
            text=text,
            text_color=COLORS["muted"],
            font=ctk.CTkFont(
                size=11
            )
        ).grid(
            row=1,
            column=column
        )


    # ========================================================
    # Saved Token
    # ========================================================

    def load_saved_token(self):

        try:

            token = keyring.get_password(
                KEYRING_SERVICE,
                KEYRING_USERNAME
            )

        except Exception:

            token = None

        if not token:
            return

        self.token_var.set(
            token
        )

        self.account_status_label.configure(
            text="저장된 계정을 확인하는 중...",
            text_color=COLORS["muted"]
        )

        self.subscription_status_label.configure(
            text=""
        )

        self.root.after(
            500,
            self.connect_account
        )


    def save_token(
        self,
        token
    ):

        keyring.set_password(
            KEYRING_SERVICE,
            KEYRING_USERNAME,
            token
        )


    def delete_saved_token(self):

        try:

            keyring.delete_password(
                KEYRING_SERVICE,
                KEYRING_USERNAME
            )

        except Exception:
            pass


    # ========================================================
    # API
    # ========================================================

    def get_token(self):

        token = (
            self.token_var
            .get()
            .strip()
        )

        if not token:

            raise ValueError(
                "Persistent API Token을 입력해주세요."
            )

        return token


    def make_headers(self):

        return {
            "Authorization":
                f"Bearer {self.get_token()}",

            "Accept":
                "application/json",

            "User-Agent":
                "NovelAI-V5-Usage-Monitor/6.0"
        }


    def api_get(
        self,
        url
    ):

        response = requests.get(
            url,
            headers=self.make_headers(),
            timeout=15
        )

        if response.status_code == 401:

            raise Exception(
                "API Token이 올바르지 않습니다."
            )

        if response.status_code == 403:

            raise Exception(
                "해당 계정으로 API에 접근할 수 없습니다."
            )

        if response.status_code == 429:

            raise Exception(
                "API 요청이 너무 많습니다."
            )

        response.raise_for_status()

        return response.json()


    # ========================================================
    # User Data
    # ========================================================

    def get_user_data(self):

        return self.api_get(
            USER_DATA_URL
        )


    # ========================================================
    # Usage
    # ========================================================

    def get_usage(self):

        data = self.api_get(
            SUBSCRIPTION_URL
        )

        usage = data.get(
            "usage"
        )

        if usage is None:

            raise Exception(
                "usage 정보를 찾을 수 없습니다."
            )

        percent = usage.get(
            "percent"
        )

        if percent is None:

            raise Exception(
                "usage.percent 값이 없습니다."
            )

        is_negative = usage.get(
            "isNegative",
            False
        )

        seconds = usage.get(
            "timeUntilNextPercent",
            0
        )

        if is_negative:

            percent = -abs(
                percent
            )

        return {
            "percent":
                percent,

            "is_negative":
                is_negative,

            "seconds_to_next":
                seconds,

            "tier":
                data.get("tier"),

            "active":
                data.get("active"),

            "expires_at":
                data.get("expiresAt")
        }


    # ========================================================
    # Connect
    # ========================================================

    def connect_account(self):

        if self.is_connected:
            return

        try:

            self.get_token()

        except ValueError as e:

            messagebox.showwarning(
                "NovelAI",
                str(e)
            )

            return

        self.connect_button.configure(
            state="disabled",
            text="확인 중..."
        )

        self.account_status_label.configure(
            text="NovelAI 계정을 확인하는 중...",
            text_color=COLORS["muted"]
        )

        self.subscription_status_label.configure(
            text=""
        )

        threading.Thread(
            target=self.connect_worker,
            daemon=True
        ).start()


    def connect_worker(self):

        try:

            # 토큰 자체 인증 확인
            self.get_user_data()

            # 실제 Usage / 구독 확인
            usage = self.get_usage()

            token = self.get_token()

            self.save_token(
                token
            )

            self.root.after(
                0,
                lambda u=usage:
                    self.on_connected(
                        u
                    )
            )

        except Exception as e:

            error = str(e)

            self.root.after(
                0,
                lambda err=error:
                    self.on_connect_failed(
                        err
                    )
            )


    def on_connected(
        self,
        usage
    ):

        self.is_connected = True

        self.subscription_tier = usage.get(
            "tier"
        )

        # ----------------------------------------------------
        # Account status
        # ----------------------------------------------------

        self.account_status_label.configure(
            text="✓ NovelAI 계정 연결됨",
            text_color=COLORS["green"]
        )

        # ----------------------------------------------------
        # Subscription status
        # ----------------------------------------------------

        tier = usage.get(
            "tier"
        )

        active = usage.get(
            "active"
        )

        if tier == 3 and active is True:

            sub_text = (
                "Opus 구독 확인됨 · V5 Usage API 정상"
            )

            sub_color = COLORS["purple_soft"]

        elif tier == 3:

            sub_text = (
                "Opus 계정 확인됨"
            )

            sub_color = COLORS["purple_soft"]

        elif tier is not None:

            sub_text = (
                f"NovelAI 구독 Tier {tier} 확인됨"
            )

            sub_color = COLORS["blue"]

        else:

            sub_text = (
                "NovelAI 구독 정보 확인됨"
            )

            sub_color = COLORS["blue"]

        self.subscription_status_label.configure(
            text=sub_text,
            text_color=sub_color
        )

        # ----------------------------------------------------
        # Token lock
        # ----------------------------------------------------

        self.token_entry.configure(
            state="disabled"
        )

        # ----------------------------------------------------
        # Buttons
        # ----------------------------------------------------

        self.connect_button.grid_remove()

        self.disconnect_button.grid(
            row=3,
            column=1,
            padx=(0, 20),
            pady=(0, 18)
        )

        # ----------------------------------------------------
        # Usage
        # ----------------------------------------------------

        self.update_usage_display(
            usage
        )

        self.set_status(
            "● NovelAI 연결 완료",
            COLORS["green"]
        )

        self.refresh_tray_menu()


    def on_connect_failed(
        self,
        error
    ):

        self.is_connected = False

        self.connect_button.configure(
            state="normal",
            text="연결"
        )

        self.account_status_label.configure(
            text="✕ 계정 연결 실패",
            text_color=COLORS["red"]
        )

        self.subscription_status_label.configure(
            text=""
        )

        self.set_status(
            f"● {error}",
            COLORS["red"]
        )

        messagebox.showerror(
            "NovelAI 연결 실패",
            error
        )


    # ========================================================
    # Disconnect
    # ========================================================

    def disconnect_account(self):

        answer = messagebox.askyesno(
            "NovelAI 계정 연결 해제",

            "저장된 API Token을 삭제하고\n"
            "NovelAI 연결을 해제할까요?"
        )

        if not answer:
            return

        self.stop_monitoring()

        self.delete_saved_token()

        self.is_connected = False
        self.subscription_tier = None

        self.current_percent = None
        self.last_usage = None

        self.alarm_triggered = False

        self.token_entry.configure(
            state="normal"
        )

        self.token_var.set("")

        self.account_status_label.configure(
            text="Persistent API Token을 입력해주세요.",
            text_color=COLORS["muted"]
        )

        self.subscription_status_label.configure(
            text=""
        )

        self.percent_label.configure(
            text="--%"
        )

        self.usage_state_label.configure(
            text="NovelAI 계정을 연결해주세요.",
            text_color=COLORS["muted"]
        )

        self.next_percent_label.configure(
            text=""
        )

        self.target_eta_label.configure(
            text=""
        )

        self.disconnect_button.grid_remove()

        self.connect_button.configure(
            state="normal",
            text="연결"
        )

        self.connect_button.grid(
            row=3,
            column=1,
            padx=(0, 20),
            pady=(0, 18)
        )

        self.last_check_label.configure(
            text="마지막 확인: -"
        )

        self.set_status(
            "● 계정 연결 해제됨",
            COLORS["muted"]
        )

        self.update_tray_title()
        self.refresh_tray_menu()


    # ========================================================
    # Refresh
    # ========================================================

    def refresh_once(self):

        if not self.is_connected:

            messagebox.showwarning(
                "NovelAI",
                "먼저 NovelAI 계정을 연결해주세요."
            )

            return

        self.refresh_button.configure(
            state="disabled",
            text="확인 중..."
        )

        threading.Thread(
            target=self.refresh_worker,
            daemon=True
        ).start()


    def refresh_worker(self):

        try:

            usage = self.get_usage()

            self.root.after(
                0,
                lambda u=usage:
                    self.update_usage_display(
                        u
                    )
            )

        except Exception as e:

            error = str(e)

            self.root.after(
                0,
                lambda err=error:
                    self.set_status(
                        f"● {err}",
                        COLORS["red"]
                    )
            )

        finally:

            self.root.after(
                0,
                lambda:
                    self.refresh_button.configure(
                        state="normal",
                        text="새로고침"
                    )
            )


    # ========================================================
    # Monitoring
    # ========================================================

    def toggle_monitoring(self):

        if self.running:

            self.stop_monitoring()

        else:

            self.start_monitoring()


    def start_monitoring(self):

        if self.running:
            return

        if not self.is_connected:

            messagebox.showwarning(
                "NovelAI",
                "먼저 NovelAI 계정을 연결해주세요."
            )

            return

        try:

            float(
                self.threshold_var.get()
            )

            interval = int(
                self.interval_var.get()
            )

            if interval < 10:
                raise ValueError

        except ValueError:

            messagebox.showerror(
                "알람 설정 오류",

                "알람 퍼센트는 숫자로 입력하고,\n"
                "확인 주기는 최소 10초 이상으로 설정해주세요."
            )

            return

        self.running = True
        self.alarm_triggered = False

        self.start_button.configure(
            text="모니터링 중지",
            fg_color="#493647",
            hover_color="#5c4358"
        )

        self.set_status(
            "● 모니터링 중",
            COLORS["green"]
        )

        self.refresh_tray_menu()
        self.update_tray_title()

        threading.Thread(
            target=self.monitor_loop,
            daemon=True
        ).start()


    def stop_monitoring(self):

        if not self.running:
            return

        self.running = False

        self.start_button.configure(
            text="모니터링 시작",
            fg_color=COLORS["purple"],
            hover_color=COLORS["purple_hover"]
        )

        self.set_status(
            "● 모니터링 중지",
            COLORS["muted"]
        )

        self.refresh_tray_menu()
        self.update_tray_title()


    def monitor_loop(self):

        while self.running:

            try:

                usage = self.get_usage()

                percent = usage[
                    "percent"
                ]

                self.root.after(
                    0,
                    lambda u=usage:
                        self.update_usage_display(
                            u
                        )
                )

                self.check_alarm(
                    percent
                )

            except Exception as e:

                error = str(e)

                self.root.after(
                    0,
                    lambda err=error:
                        self.set_status(
                            f"● {err}",
                            COLORS["red"]
                        )
                )

            try:

                interval = max(
                    10,
                    int(
                        self.interval_var.get()
                    )
                )

            except ValueError:

                interval = 60

            for _ in range(
                interval
            ):

                if not self.running:
                    return

                time.sleep(1)


    # ========================================================
    # Alarm
    # ========================================================

    def check_alarm(
        self,
        current_percent
    ):

        try:

            threshold = float(
                self.threshold_var.get()
            )

        except ValueError:
            return

        condition = (
            self.condition_var.get()
        )

        if condition == "이상":

            matched = (
                current_percent
                >= threshold
            )

        elif condition == "이하":

            matched = (
                current_percent
                <= threshold
            )

        else:

            matched = (
                current_percent
                == threshold
            )

        if (
            matched
            and
            not self.alarm_triggered
        ):

            self.alarm_triggered = True

            self.root.after(
                0,
                lambda:
                    self.send_notification(
                        current_percent,
                        threshold,
                        condition
                    )
            )

        elif not matched:

            self.alarm_triggered = False


    def send_notification(
        self,
        percent,
        threshold,
        condition
    ):

        title = (
            "NovelAI V5 충전 알림"
        )

        message = (
            f"현재 Usage Limit: {percent}%\n"
            f"설정 조건: {threshold:g}% {condition}"
        )

        if PLYER_AVAILABLE:

            try:

                notification.notify(
                    title=title,
                    message=message,
                    app_name=APP_NAME,
                    timeout=10
                )

            except Exception:
                pass

        try:

            if self.tray_icon:

                self.tray_icon.notify(
                    message,
                    title
                )

        except Exception:
            pass

        try:
            self.root.bell()
        except Exception:
            pass

        self.set_status(
            f"● 알람 발생 · {percent}%",
            COLORS["purple_soft"]
        )


    # ========================================================
    # ETA
    # ========================================================

    def calculate_target_eta(
        self,
        current_percent,
        target_percent,
        seconds_to_next,
        condition
    ):

        if condition == "이하":

            return {
                "state": "not_applicable",
                "seconds": None
            }

        if target_percent > 100:

            return {
                "state": "above_cap",
                "seconds": None
            }

        if current_percent >= target_percent:

            return {
                "state": "reached",
                "seconds": 0
            }

        difference = (
            target_percent
            - current_percent
        )

        try:

            seconds_to_next = float(
                seconds_to_next
            )

        except (TypeError, ValueError):

            seconds_to_next = 0

        if seconds_to_next > 0:

            remaining = seconds_to_next

            remaining_steps = max(
                0,
                difference - 1
            )

            remaining += (
                remaining_steps
                * REFILL_SECONDS_PER_PERCENT
            )

        else:

            remaining = (
                difference
                * REFILL_SECONDS_PER_PERCENT
            )

        return {
            "state": "charging",
            "seconds": int(remaining)
        }


    def update_target_eta(
        self,
        current_percent,
        seconds_to_next
    ):

        if current_percent is None:

            self.target_eta_label.configure(
                text=""
            )

            return

        try:

            target = float(
                self.threshold_var.get()
            )

        except ValueError:

            self.target_eta_label.configure(
                text="목표 퍼센트를 숫자로 입력해주세요.",
                text_color=COLORS["red"]
            )

            return

        condition = (
            self.condition_var.get()
        )

        result = self.calculate_target_eta(
            current_percent,
            target,
            seconds_to_next,
            condition
        )

        state = result[
            "state"
        ]

        if state == "not_applicable":

            text = (
                "‘이하’ 조건은 충전 ETA를 계산하지 않습니다."
            )

            color = COLORS["muted"]

        elif state == "above_cap":

            text = (
                f"{target:g}%는 자동 충전으로 도달할 수 없습니다."
            )

            color = COLORS["yellow"]

        elif state == "reached":

            text = (
                f"목표 {target:g}% 도달 완료"
            )

            color = COLORS["green"]

        else:

            seconds = result[
                "seconds"
            ]

            text = (
                f"목표 {target:g}%까지 약 "
                f"{self.format_seconds(seconds)}"
            )

            color = COLORS["purple_soft"]

        self.target_eta_label.configure(
            text=text,
            text_color=color
        )


    def on_threshold_changed(
        self,
        *args
    ):

        if (
            self.current_percent is None
            or
            self.last_usage is None
        ):
            return

        self.update_target_eta(
            self.current_percent,
            self.last_usage.get(
                "seconds_to_next",
                0
            )
        )


    def on_target_setting_changed(
        self,
        value=None
    ):

        self.on_threshold_changed()


    # ========================================================
    # Display
    # ========================================================

    def update_usage_display(
        self,
        usage
    ):

        self.last_usage = usage

        percent = usage[
            "percent"
        ]

        seconds = usage[
            "seconds_to_next"
        ]

        tier = usage.get(
            "tier"
        )

        active = usage.get(
            "active"
        )

        self.current_percent = percent

        # ----------------------------------------------------
        # Percent
        # ----------------------------------------------------

        self.percent_label.configure(
            text=f"{percent}%"
        )

        # ----------------------------------------------------
        # State
        # ----------------------------------------------------

        if percent > 100:

            state = (
                "보너스 Usage 사용 가능"
            )

            color = COLORS["purple_soft"]

        elif percent == 100:

            state = (
                "완전히 충전됨"
            )

            color = COLORS["green"]

        elif percent >= 0:

            state = (
                "충전 중"
            )

            color = COLORS["yellow"]

        else:

            state = (
                "Usage Limit 초과"
            )

            color = COLORS["red"]

        if tier == 3:

            state += " · Opus"

        elif tier is not None:

            state += f" · Tier {tier}"

        self.usage_state_label.configure(
            text=state,
            text_color=color
        )

        # ----------------------------------------------------
        # Subscription display refresh
        # ----------------------------------------------------

        if tier == 3 and active is True:

            self.subscription_status_label.configure(
                text="Opus 구독 확인됨 · V5 Usage API 정상",
                text_color=COLORS["purple_soft"]
            )

        elif tier == 3:

            self.subscription_status_label.configure(
                text="Opus 계정 확인됨",
                text_color=COLORS["purple_soft"]
            )

        elif tier is not None:

            self.subscription_status_label.configure(
                text=f"NovelAI 구독 Tier {tier} 확인됨",
                text_color=COLORS["blue"]
            )

        # ----------------------------------------------------
        # Next +1%
        # ----------------------------------------------------

        try:

            seconds_float = float(
                seconds
            )

        except (TypeError, ValueError):

            seconds_float = 0

        if seconds_float > 0:

            self.next_percent_label.configure(
                text=(
                    "다음 +1%까지 "
                    f"{self.format_seconds(seconds_float)}"
                )
            )

        else:

            self.next_percent_label.configure(
                text=""
            )

        # ----------------------------------------------------
        # ETA
        # ----------------------------------------------------

        self.update_target_eta(
            percent,
            seconds_float
        )

        # ----------------------------------------------------
        # Last check
        # ----------------------------------------------------

        now = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        self.last_check_label.configure(
            text=f"마지막 확인: {now}"
        )

        if self.running:

            self.set_status(
                "● 모니터링 중",
                COLORS["green"]
            )

        else:

            self.set_status(
                "● 최신 Usage 정보를 불러옴",
                COLORS["blue"]
            )

        self.update_tray_title()


    # ========================================================
    # Time Formatting
    # ========================================================

    def format_seconds(
        self,
        seconds
    ):

        seconds = max(
            0,
            int(seconds)
        )

        days, seconds = divmod(
            seconds,
            86400
        )

        hours, seconds = divmod(
            seconds,
            3600
        )

        minutes, seconds = divmod(
            seconds,
            60
        )

        if days > 0:

            return (
                f"{days}일 "
                f"{hours}시간 "
                f"{minutes}분"
            )

        if hours > 0:

            return (
                f"{hours}시간 "
                f"{minutes}분"
            )

        if minutes > 0:

            return (
                f"{minutes}분 "
                f"{seconds}초"
            )

        return (
            f"{seconds}초"
        )


    # ========================================================
    # Status
    # ========================================================

    def set_status(
        self,
        text,
        color
    ):

        self.status_label.configure(
            text=text,
            text_color=color
        )


    # ========================================================
    # Tray Icon
    # ========================================================

    def create_tray_image(self):

        size = 64

        image = Image.new(
            "RGBA",
            (size, size),
            (0, 0, 0, 0)
        )

        draw = ImageDraw.Draw(
            image
        )

        # Outer circle
        draw.ellipse(
            (3, 3, 61, 61),
            fill=(
                18,
                17,
                33,
                255
            ),
            outline=(
                141,
                114,
                255,
                255
            ),
            width=4
        )

        # Diamond
        draw.polygon(
            [
                (32, 11),
                (52, 32),
                (32, 53),
                (12, 32)
            ],
            fill=(
                115,
                91,
                220,
                255
            )
        )

        # Star
        draw.polygon(
            [
                (32, 17),
                (36, 28),
                (47, 32),
                (36, 36),
                (32, 47),
                (28, 36),
                (17, 32),
                (28, 28)
            ],
            fill=(
                241,
                238,
                255,
                255
            )
        )

        return image


    # ========================================================
    # Tray
    # ========================================================

    def create_tray(self):

        self.tray_icon = pystray.Icon(
            "NovelAI-V5-Usage-Monitor",
            self.create_tray_image(),
            APP_NAME,
            self.build_tray_menu()
        )

        self.tray_thread = threading.Thread(
            target=self.tray_icon.run,
            daemon=True
        )

        self.tray_thread.start()


    def build_tray_menu(self):

        monitor_text = (
            "모니터링 중지"
            if self.running
            else
            "모니터링 시작"
        )

        return pystray.Menu(

            pystray.MenuItem(
                "NovelAI V5 Usage Monitor",
                None,
                enabled=False
            ),

            pystray.Menu.SEPARATOR,

            pystray.MenuItem(
                "열기",
                self.tray_show,
                default=True
            ),

            pystray.MenuItem(
                "새로고침",
                self.tray_refresh
            ),

            pystray.MenuItem(
                monitor_text,
                self.tray_toggle_monitor
            ),

            pystray.Menu.SEPARATOR,

            pystray.MenuItem(
                "종료",
                self.tray_exit
            )
        )


    def refresh_tray_menu(self):

        if not self.tray_icon:
            return

        try:

            self.tray_icon.menu = (
                self.build_tray_menu()
            )

            self.tray_icon.update_menu()

        except Exception:
            pass


    def update_tray_title(self):

        if not self.tray_icon:
            return

        try:

            if self.current_percent is None:

                title = APP_NAME

            else:

                title = (
                    f"NovelAI V5 · "
                    f"{self.current_percent}%"
                )

                if self.running:

                    title += (
                        " · Monitoring"
                    )

            self.tray_icon.title = title

        except Exception:
            pass


    # ========================================================
    # Tray actions
    # ========================================================

    def hide_to_tray(self):

        if self.app_exiting:
            return

        self.root.withdraw()

        self.update_tray_title()


    def tray_show(
        self,
        icon=None,
        item=None
    ):

        self.root.after(
            0,
            self.show_window
        )


    def show_window(self):

        self.root.deiconify()

        self.root.state(
            "normal"
        )

        self.root.lift()

        try:

            self.root.focus_force()

        except Exception:
            pass


    def tray_refresh(
        self,
        icon=None,
        item=None
    ):

        self.root.after(
            0,
            self.refresh_once
        )


    def tray_toggle_monitor(
        self,
        icon=None,
        item=None
    ):

        self.root.after(
            0,
            self.toggle_monitoring
        )


    def tray_exit(
        self,
        icon=None,
        item=None
    ):

        self.app_exiting = True

        self.running = False

        try:

            if self.tray_icon:

                self.tray_icon.stop()

        except Exception:
            pass

        self.root.after(
            0,
            self.root.destroy
        )


    # ========================================================
    # Run
    # ========================================================

    def run(self):

        self.root.mainloop()


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":

    app = NovelAIUsageMonitor()

    app.run()
