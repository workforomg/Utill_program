﻿@echo off
chcp 65001 >nul
title NovelAI V5 Usage Monitor - Dependencies

echo.
echo ==========================================
echo  NovelAI V5 Usage Monitor
echo  필요한 Python 패키지를 설치합니다.
echo ==========================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    py -m pip install --upgrade pip
    py -m pip install -r "%~dp0requirements.txt"
) else (
    python -m pip install --upgrade pip
    python -m pip install -r "%~dp0requirements.txt"
)

echo.
if %errorlevel%==0 (
    echo 설치가 완료되었습니다.
) else (
    echo 설치 중 오류가 발생했습니다.
    echo Python이 설치되어 있고 PATH가 설정되어 있는지 확인하세요.
)

echo.
pause
